# composer.online
A NodeJS Web Application Design for Who Doesnt has Composer Feature or SSH Access on their web hosting

### Server
#### Install Package
```
npm i 
```
#### Change PHP Executable
at line 143. Please change PHP Executable to your PHP Executable Path
### Client
Just Upload All Things Except server folder

#### Setup
in `js/composer.js` please change `ws://localhost:8080 to your server url`